saisirUnNombre= int(input("Veuillez saisir un nombre : "))
# print("1*saisirUnNombre)
# print(2*saisirUnNombre)
# print(3*saisirUnNombre)
# print(4*saisirUnNombre)
# print(5*saisirUnNombre)
# print(6*saisirUnNombre)
# print(7*saisirUnNombre)
# print(8*saisirUnNombre)
# print(9*saisirUnNombre)
# print(10*saisirUnNombre)

# correction
# print(f"1 x {saisirUnNombre}= {1*n}")
# print(f"2 x {saisirUnNombre}= {2*n}")
# print(f"3 x {saisirUnNombre}= {3*n}")
# print(f"4 x {saisirUnNombre}= {4*n}")
# print(f"5 x {saisirUnNombre}= {5*n}")
# print(f"6 x {saisirUnNombre}= {6*n}")
# print(f"7 x {saisirUnNombre}= {7*n}")
# print(f"8 x {saisirUnNombre}= {8*n}")
# print(f"9 x {saisirUnNombre}= {9*n}")
# print(f"10 x {saisirUnNombre}= {10*n}")


for i in range (1,11):
  print (f"{i} x {saisirUnNombre} = {i*saisirUnNombre}")

# for i in range(1,11):
#   for j in range(1,11):
#     print(i*j, end=" ")
#   print('')