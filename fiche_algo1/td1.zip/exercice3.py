#  Calculer l'air d'un carré

x = int(input("Saissisez le coté d'un carré: "))
airCarre = x*x
print("l'air du carré est de : ",airCarre)

# Correction
x = float(input("Veuillez saisir le coté du carré en (cm) : "))
print(f"L'air du carré es de {x*x} cm²")