# Calculer l'age a partir d'une date de naissance

annee_naissance = int(input("Saisir votre anée de naissance : "))
print(f"Vous Avez {2023-annee_naissance} ans.")