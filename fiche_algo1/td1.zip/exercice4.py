#  Permet de saluer une personne

firstname = str(input("Veuillez saisir votre prénom."))
print(f"Hello {firstname}")
