# Permet de calculer le double d'un nombre

x= int(input("Saisir un nombre: "))
double = x*2
print("le resultat est",double)

# plus court
print("Le double de",x,"est", x*2)

# formatted string
print(f"Le double de {x} est {x*2}")

