# Calculer le volume d'un parallélépipède

largeur= float(input("Veuillez saisir la largeur : "))
longueur = float(input("Veuillez saisir la longueur : "))
hauteur = float(input("Veuillez saisir la hauteur : "))

volume = largeur * longueur * hauteur 

print(f"Le volume est de : {volume}")

